<!doctype html>
<html lang="id">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v27.6 - https://yoast.com/product/yoast-seo-wordpress/ -->
	<title>Page not found - Walimatul iD</title>
	<meta property="og:locale" content="id_ID" />
	<meta property="og:title" content="Page not found - Walimatul iD" />
	<meta property="og:site_name" content="Walimatul iD" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https:\/\/schema.org","@graph":[{"@type":"WebSite","@id":"https:\/\/walimatul.id\/#website","url":"https:\/\/walimatul.id\/","name":"Walimatul ID","description":"Buat Website Undangan Digital","publisher":{"@id":"https:\/\/walimatul.id\/#organization"},"alternateName":"Undangan Pernikahan Digital","potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https:\/\/walimatul.id\/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"id"},{"@type":"Organization","@id":"https:\/\/walimatul.id\/#organization","name":"Walimatul iD","url":"https:\/\/walimatul.id\/","logo":{"@type":"ImageObject","inLanguage":"id","@id":"https:\/\/walimatul.id\/#\/schema\/logo\/image\/","url":"https:\/\/walimatul.id\/wp-content\/uploads\/2024\/03\/logo-walimatul-tf-light-1.webp","contentUrl":"https:\/\/walimatul.id\/wp-content\/uploads\/2024\/03\/logo-walimatul-tf-light-1.webp","width":2132,"height":477,"caption":"Walimatul iD"},"image":{"@id":"https:\/\/walimatul.id\/#\/schema\/logo\/image\/"}}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com' />
<style id='wp-img-auto-sizes-contain-inline-css'>
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://walimatul.id/wp-includes/css/dist/block-library/style.min.css?ver=6.9.4' media='all' />
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}:root { --wp--style--global--content-size: 800px;--wp--style--global--wide-size: 1200px; }:where(body) { margin: 0; }.wp-site-blocks > .alignleft { float: left; margin-right: 2em; }.wp-site-blocks > .alignright { float: right; margin-left: 2em; }.wp-site-blocks > .aligncenter { justify-content: center; margin-left: auto; margin-right: auto; }:where(.wp-site-blocks) > * { margin-block-start: 24px; margin-block-end: 0; }:where(.wp-site-blocks) > :first-child { margin-block-start: 0; }:where(.wp-site-blocks) > :last-child { margin-block-end: 0; }:root { --wp--style--block-gap: 24px; }:root :where(.is-layout-flow) > :first-child{margin-block-start: 0;}:root :where(.is-layout-flow) > :last-child{margin-block-end: 0;}:root :where(.is-layout-flow) > *{margin-block-start: 24px;margin-block-end: 0;}:root :where(.is-layout-constrained) > :first-child{margin-block-start: 0;}:root :where(.is-layout-constrained) > :last-child{margin-block-end: 0;}:root :where(.is-layout-constrained) > *{margin-block-start: 24px;margin-block-end: 0;}:root :where(.is-layout-flex){gap: 24px;}:root :where(.is-layout-grid){gap: 24px;}.is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}.is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}.is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}.is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}a:where(:not(.wp-element-button)){text-decoration: underline;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
/*# sourceURL=global-styles-inline-css */
</style>
<link rel='stylesheet' id='wdp-centered-css-css' href='https://walimatul.id/wp-content/plugins/weddingpress/assets/css/wdp-centered-timeline.min.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='wdp-horizontal-css-css' href='https://walimatul.id/wp-content/plugins/weddingpress/assets/css/wdp-horizontal-styles.min.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='wdp-fontello-css-css' href='https://walimatul.id/wp-content/plugins/weddingpress/assets/css/wdp-fontello.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='exad-main-style-css' href='https://walimatul.id/wp-content/plugins/weddingpress/assets/css/exad-styles.min.css?ver=6.9.4' media='all' />
<link rel='stylesheet' id='wds-elementor-css' href='https://walimatul.id/wp-content/plugins/weddingsaas-pro/assets/css/wds-elementor.css?ver=2.9.1' media='all' />
<link rel='stylesheet' id='saic_style-css' href='https://walimatul.id/wp-content/plugins/weddingsaas-pro/assets/plugins/custom/commentpress/saic_style.css?ver=2.9.1' media='screen' />
<link rel='stylesheet' id='hello-elementor-css' href='https://walimatul.id/wp-content/themes/hello-elementor/assets/css/reset.css?ver=3.4.7' media='all' />
<link rel='stylesheet' id='hello-elementor-theme-style-css' href='https://walimatul.id/wp-content/themes/hello-elementor/assets/css/theme.css?ver=3.4.7' media='all' />
<link rel='stylesheet' id='hello-elementor-header-footer-css' href='https://walimatul.id/wp-content/themes/hello-elementor/assets/css/header-footer.css?ver=3.4.7' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://walimatul.id/wp-content/plugins/elementor/assets/css/frontend.min.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='elementor-post-6-css' href='https://walimatul.id/wp-content/uploads/elementor/css/post-6.css?ver=1779014509' media='all' />
<link rel='stylesheet' id='jet-fb-option-field-select-css' href='https://walimatul.id/wp-content/plugins/jetformbuilder/modules/option-field/assets/build/select.css?ver=0edd78a6f12e2b918b82' media='all' />
<link rel='stylesheet' id='jet-fb-option-field-checkbox-css' href='https://walimatul.id/wp-content/plugins/jetformbuilder/modules/option-field/assets/build/checkbox.css?ver=6e25adbbae5a5d1bb65e' media='all' />
<link rel='stylesheet' id='jet-fb-option-field-radio-css' href='https://walimatul.id/wp-content/plugins/jetformbuilder/modules/option-field/assets/build/radio.css?ver=7c6d0d4d7df91e6bd6a4' media='all' />
<link rel='stylesheet' id='jet-fb-advanced-choices-css' href='https://walimatul.id/wp-content/plugins/jetformbuilder/modules/advanced-choices/assets/build/main.css?ver=ca05550a7cac3b9b55a3' media='all' />
<link rel='stylesheet' id='jet-fb-wysiwyg-css' href='https://walimatul.id/wp-content/plugins/jetformbuilder/modules/wysiwyg/assets/build/wysiwyg.css?ver=5a4d16fb6d7a94700261' media='all' />
<link rel='stylesheet' id='jet-fb-switcher-css' href='https://walimatul.id/wp-content/plugins/jetformbuilder/modules/switcher/assets/build/switcher.css?ver=06c887a8b9195e5a119d' media='all' />
<link rel='stylesheet' id='jet-fb-multi-gateway-css' href='https://walimatul.id/wp-content/plugins/jetformbuilder/modules/multi-gateway/assets/build/multi-gateway.css?ver=47bf27f09045105a3c5d' media='all' />
<link rel='stylesheet' id='widget-image-css' href='https://walimatul.id/wp-content/plugins/elementor/assets/css/widget-image.min.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='widget-nav-menu-css' href='https://walimatul.id/wp-content/plugins/elementor-pro/assets/css/widget-nav-menu.min.css?ver=4.0.4' media='all' />
<link rel='stylesheet' id='widget-social-icons-css' href='https://walimatul.id/wp-content/plugins/elementor/assets/css/widget-social-icons.min.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='e-apple-webkit-css' href='https://walimatul.id/wp-content/plugins/elementor/assets/css/conditionals/apple-webkit.min.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='widget-heading-css' href='https://walimatul.id/wp-content/plugins/elementor/assets/css/widget-heading.min.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='widget-icon-list-css' href='https://walimatul.id/wp-content/plugins/elementor/assets/css/widget-icon-list.min.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='e-sticky-css' href='https://walimatul.id/wp-content/plugins/elementor-pro/assets/css/modules/sticky.min.css?ver=4.0.4' media='all' />
<link rel='stylesheet' id='weddingpress-wdp-css' href='https://walimatul.id/wp-content/plugins/weddingpress/assets/css/wdp.css?ver=2.10' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css' href='https://walimatul.id/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css' href='https://walimatul.id/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=4.0.8' media='all' />
<link rel='stylesheet' id='elementor-post-2469-css' href='https://walimatul.id/wp-content/uploads/elementor/css/post-2469.css?ver=1779014533' media='all' />
<link rel='stylesheet' id='elementor-post-2473-css' href='https://walimatul.id/wp-content/uploads/elementor/css/post-2473.css?ver=1779014510' media='all' />
<link rel='stylesheet' id='elementor-gf-local-cormorant-css' href='https://walimatul.id/wp-content/uploads/elementor/google-fonts/css/cormorant.css?ver=1742706129' media='all' />
<link rel='stylesheet' id='elementor-gf-local-jost-css' href='https://walimatul.id/wp-content/uploads/elementor/google-fonts/css/jost.css?ver=1745253778' media='all' />
<link rel='stylesheet' id='elementor-gf-local-outfit-css' href='https://walimatul.id/wp-content/uploads/elementor/google-fonts/css/outfit.css?ver=1742664699' media='all' />
<script src="https://walimatul.id/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://walimatul.id/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script src="https://walimatul.id/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=4.0.8" id="font-awesome-4-shim-js"></script>

<!-- Potongan tag Google (gtag.js) ditambahkan oleh Site Kit -->
<!-- Snippet Google Analytics telah ditambahkan oleh Site Kit -->
<script src="https://www.googletagmanager.com/gtag/js?id=GT-NCL6ZNTQ" id="google_gtagjs-js" async></script>
<script id="google_gtagjs-js-after">
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}
gtag("set","linker",{"domains":["walimatul.id"]});
gtag("js", new Date());
gtag("set", "developer_id.dZTNiMT", true);
gtag("config", "GT-NCL6ZNTQ");
 window._googlesitekit = window._googlesitekit || {}; window._googlesitekit.throttledEvents = []; window._googlesitekit.gtagEvent = (name, data) => { var key = JSON.stringify( { name, data } ); if ( !! window._googlesitekit.throttledEvents[ key ] ) { return; } window._googlesitekit.throttledEvents[ key ] = true; setTimeout( () => { delete window._googlesitekit.throttledEvents[ key ]; }, 5 ); gtag( "event", name, { ...data, event_source: "site-kit" } ); }; 
//# sourceURL=google_gtagjs-js-after
</script>
<link rel="https://api.w.org/" href="https://walimatul.id/wp-json/" /><meta name="generator" content="Site Kit by Google 1.178.0" /><!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1078401663460589');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=1078401663460589&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code --><meta name="generator" content="Elementor 4.0.8; features: e_font_icon_svg, additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-swap">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<style class="wpcode-css-snippet">input[type="text"].form-control, select.form-control {
    border-radius: 8px;
    border: 1px solid #ccc !important;
    box-shadow: 0 0px 0px rgba(0, 0, 0, .0);
    color: #555f77;
    padding: 9px 15px;
    margin-bottom: 0px !important;
    
}

.jet-form-builder-row.field-type-select-field.wp-block-jet-forms-select-field.cb-sg9hyqks.p-0.mb-5 {
    display: none;
}

.jet-form-builder-row.field-type-select-field.wp-block-jet-forms-select-field.cb-qpelnqyy.p-0.mb-5 {
	display: none;
}

.jet-form-builder-file-upload__content {
    min-height: 80px !important;
    min-width: 80px !important;
    border-radius: 8px !important;
}
.jet-form-builder-row.field-type-media-field.p-0.mb-5 {
    padding: 15px !important;
    border-radius: 15px !important;
    border: dashed 2px #ddd;
}</style><style>
.jet-form-builder-row textarea {    height: 7.5em; /* atur sesuai keinginan*/
}
</style><link rel="icon" href="https://walimatul.id/wp-content/uploads/2024/03/icon.webp" sizes="32x32" />
<link rel="icon" href="https://walimatul.id/wp-content/uploads/2024/03/icon.webp" sizes="192x192" />
<link rel="apple-touch-icon" href="https://walimatul.id/wp-content/uploads/2024/03/icon.webp" />
<meta name="msapplication-TileImage" content="https://walimatul.id/wp-content/uploads/2024/03/icon.webp" />
		<style id="wp-custom-css">
			svg.e-font-icon-svg.e-fab-whatsapp {
    display: none;
}		</style>
		</head>
<body class="error404 wp-custom-logo wp-embed-responsive wp-theme-hello-elementor hello-elementor-default elementor-default elementor-kit-6">


<a class="skip-link screen-reader-text" href="#content">Lewati ke konten</a>

		<header data-elementor-type="header" data-elementor-id="2469" class="elementor elementor-2469 elementor-location-header" data-elementor-post-type="elementor_library">
			<div class="elementor-element elementor-element-f2acf9d e-flex e-con-boxed wdp-sticky-section-no e-con e-parent" data-id="f2acf9d" data-element_type="container" data-e-type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-0c9435a e-con-full e-flex wdp-sticky-section-no e-con e-child" data-id="0c9435a" data-element_type="container" data-e-type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
				<div class="elementor-element elementor-element-642a2b3 wdp-sticky-section-no elementor-widget elementor-widget-image" data-id="642a2b3" data-element_type="widget" data-e-type="widget" data-widget_type="image.default">
																<a href="/">
							<img fetchpriority="high" width="800" height="179" src="https://walimatul.id/wp-content/uploads/2024/03/logo-walimatul-tf-light-1.webp" class="attachment-large size-large wp-image-1179" alt="" />								</a>
															</div>
				</div>
		<div class="elementor-element elementor-element-32e69c4 e-con-full e-flex wdp-sticky-section-no e-con e-child" data-id="32e69c4" data-element_type="container" data-e-type="container">
				<div class="elementor-element elementor-element-a20f01b elementor-nav-menu--stretch elementor-hidden-desktop elementor-hidden-tablet elementor-hidden-mobile elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger wdp-sticky-section-no elementor-widget elementor-widget-nav-menu" data-id="a20f01b" data-element_type="widget" data-e-type="widget" data-settings="{&quot;full_width&quot;:&quot;stretch&quot;,&quot;submenu_icon&quot;:{&quot;value&quot;:&quot;&lt;svg aria-hidden=\&quot;true\&quot; class=\&quot;fa-svg-chevron-down e-font-icon-svg e-fas-chevron-down\&quot; viewBox=\&quot;0 0 448 512\&quot; xmlns=\&quot;http:\/\/www.w3.org\/2000\/svg\&quot;&gt;&lt;path d=\&quot;M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z\&quot;&gt;&lt;\/path&gt;&lt;\/svg&gt;&quot;,&quot;library&quot;:&quot;fa-solid&quot;},&quot;layout&quot;:&quot;horizontal&quot;,&quot;toggle&quot;:&quot;burger&quot;}" data-widget_type="nav-menu.default">
								<nav aria-label="Menu" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-underline e--animation-fade">
				<ul id="menu-1-a20f01b" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-4022"><a href="https://walimatul.id/" class="elementor-item">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4045"><a href="https://walimatul.id/tema-custom/" class="elementor-item">Tema</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4042"><a href="https://walimatul.id/undangan-video/" class="elementor-item">Undangan Video</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4043"><a href="https://walimatul.id/article/" class="elementor-item">Blog</a></li>
</ul>			</nav>
					<div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false">
			<span class="elementor-menu-toggle__icon--open"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" width="50px" height="50px"><path d="M 3 9 A 1.0001 1.0001 0 1 0 3 11 L 47 11 A 1.0001 1.0001 0 1 0 47 9 L 3 9 z M 3 24 A 1.0001 1.0001 0 1 0 3 26 L 47 26 A 1.0001 1.0001 0 1 0 47 24 L 3 24 z M 3 39 A 1.0001 1.0001 0 1 0 3 41 L 47 41 A 1.0001 1.0001 0 1 0 47 39 L 3 39 z"></path></svg></span><span class="elementor-menu-toggle__icon--close"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" width="50px" height="50px"><path d="M 7.71875 6.28125 L 6.28125 7.71875 L 23.5625 25 L 6.28125 42.28125 L 7.71875 43.71875 L 25 26.4375 L 42.28125 43.71875 L 43.71875 42.28125 L 26.4375 25 L 43.71875 7.71875 L 42.28125 6.28125 L 25 23.5625 Z"></path></svg></span>		</div>
					<nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true">
				<ul id="menu-2-a20f01b" class="elementor-nav-menu"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-4022"><a href="https://walimatul.id/" class="elementor-item" tabindex="-1">Home</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4045"><a href="https://walimatul.id/tema-custom/" class="elementor-item" tabindex="-1">Tema</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4042"><a href="https://walimatul.id/undangan-video/" class="elementor-item" tabindex="-1">Undangan Video</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4043"><a href="https://walimatul.id/article/" class="elementor-item" tabindex="-1">Blog</a></li>
</ul>			</nav>
						</div>
				<div class="elementor-element elementor-element-0d3a41b wdsdv-enabled--yes wdp-sticky-section-no elementor-widget elementor-widget-button" data-id="0d3a41b" data-element_type="widget" data-e-type="widget" data-widget_type="button.default">
										<a class="elementor-button elementor-button-link elementor-size-sm" href="https://walimatul.id/auth/login/">
						<span class="elementor-button-content-wrapper">
									<span class="elementor-button-text">Masuk</span>
					</span>
					</a>
								</div>
				</div>
					</div>
				</div>
				</header>
		<main id="content" class="site-main">

			<div class="page-header">
			<h1 class="entry-title">Halaman tidak dapat ditemukan.</h1>
		</div>
	
	<div class="page-content">
		<p>Sepertinya tidak ada yang ditemukan di lokasi ini.</p>
	</div>

</main>
		<footer data-elementor-type="footer" data-elementor-id="2473" class="elementor elementor-2473 elementor-location-footer" data-elementor-post-type="elementor_library">
			<div class="elementor-element elementor-element-7a8ae37 e-flex e-con-boxed wdp-sticky-section-no e-con e-parent" data-id="7a8ae37" data-element_type="container" data-e-type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-3a4c8a2 e-con-full e-flex wdp-sticky-section-no e-con e-child" data-id="3a4c8a2" data-element_type="container" data-e-type="container">
				<div class="elementor-element elementor-element-6d9481d elementor-widget elementor-widget-image" data-id="6d9481d" data-element_type="widget" data-e-type="widget" data-widget_type="image.default">
															<img width="827" height="150" src="https://walimatul.id/wp-content/uploads/2024/02/logo-walimatul.webp" class="attachment-full size-full wp-image-4017" alt="" />															</div>
				<div class="elementor-element elementor-element-cf3edd7 wdp-sticky-section-no elementor-widget elementor-widget-text-editor" data-id="cf3edd7" data-element_type="widget" data-e-type="widget" data-widget_type="text-editor.default">
									Walimatul iD adalah platform untuk membuat website undangan digital dengan layanan lengkap. Visi Kami menjadi solusi layanan untuk undangan digital impian Anda.
								</div>
				<div class="elementor-element elementor-element-ac78511 e-grid-align-left elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons" data-id="ac78511" data-element_type="widget" data-e-type="widget" data-widget_type="social-icons.default">
							<div class="elementor-social-icons-wrapper elementor-grid" role="list">
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-9fbf257" target="_blank">
						<span class="elementor-screen-only">Instagram</span>
						<svg aria-hidden="true" class="e-font-icon-svg e-fab-instagram" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-tiktok elementor-repeater-item-e4fb97a" target="_blank">
						<span class="elementor-screen-only">Tiktok</span>
						<svg aria-hidden="true" class="e-font-icon-svg e-fab-tiktok" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M448,209.91a210.06,210.06,0,0,1-122.77-39.25V349.38A162.55,162.55,0,1,1,185,188.31V278.2a74.62,74.62,0,1,0,52.23,71.18V0l88,0a121.18,121.18,0,0,0,1.86,22.17h0A122.18,122.18,0,0,0,381,102.39a121.43,121.43,0,0,0,67,20.14Z"></path></svg>					</a>
				</span>
							<span class="elementor-grid-item" role="listitem">
					<a class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-repeater-item-c96c2f6" target="_blank">
						<span class="elementor-screen-only">Youtube</span>
						<svg aria-hidden="true" class="e-font-icon-svg e-fab-youtube" viewBox="0 0 576 512" xmlns="http://www.w3.org/2000/svg"><path d="M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z"></path></svg>					</a>
				</span>
					</div>
						</div>
				</div>
		<div class="elementor-element elementor-element-518434b e-con-full e-flex wdp-sticky-section-no e-con e-child" data-id="518434b" data-element_type="container" data-e-type="container">
				<div class="elementor-element elementor-element-66f18c5 elementor-widget elementor-widget-heading" data-id="66f18c5" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Informasi Kontak</h3>				</div>
				<div class="elementor-element elementor-element-389e3d4 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="389e3d4" data-element_type="widget" data-e-type="widget" data-widget_type="icon-list.default">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-whatsapp-square" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224 122.8c-72.7 0-131.8 59.1-131.9 131.8 0 24.9 7 49.2 20.2 70.1l3.1 5-13.3 48.6 49.9-13.1 4.8 2.9c20.2 12 43.4 18.4 67.1 18.4h.1c72.6 0 133.3-59.1 133.3-131.8 0-35.2-15.2-68.3-40.1-93.2-25-25-58-38.7-93.2-38.7zm77.5 188.4c-3.3 9.3-19.1 17.7-26.7 18.8-12.6 1.9-22.4.9-47.5-9.9-39.7-17.2-65.7-57.2-67.7-59.8-2-2.6-16.2-21.5-16.2-41s10.2-29.1 13.9-33.1c3.6-4 7.9-5 10.6-5 2.6 0 5.3 0 7.6.1 2.4.1 5.7-.9 8.9 6.8 3.3 7.9 11.2 27.4 12.2 29.4s1.7 4.3.3 6.9c-7.6 15.2-15.7 14.6-11.6 21.6 15.3 26.3 30.6 35.4 53.9 47.1 4 2 6.3 1.7 8.6-1 2.3-2.6 9.9-11.6 12.5-15.5 2.6-4 5.3-3.3 8.9-2 3.6 1.3 23.1 10.9 27.1 12.9s6.6 3 7.6 4.6c.9 1.9.9 9.9-2.4 19.1zM400 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zM223.9 413.2c-26.6 0-52.7-6.7-75.8-19.3L64 416l22.5-82.2c-13.9-24-21.2-51.3-21.2-79.3C65.4 167.1 136.5 96 223.9 96c42.4 0 82.2 16.5 112.2 46.5 29.9 30 47.9 69.8 47.9 112.2 0 87.4-72.7 158.5-160.1 158.5z"></path></svg>						</span>
										<span class="elementor-icon-list-text">Admin 1: 0851 2800 2066</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fab-whatsapp-square" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M224 122.8c-72.7 0-131.8 59.1-131.9 131.8 0 24.9 7 49.2 20.2 70.1l3.1 5-13.3 48.6 49.9-13.1 4.8 2.9c20.2 12 43.4 18.4 67.1 18.4h.1c72.6 0 133.3-59.1 133.3-131.8 0-35.2-15.2-68.3-40.1-93.2-25-25-58-38.7-93.2-38.7zm77.5 188.4c-3.3 9.3-19.1 17.7-26.7 18.8-12.6 1.9-22.4.9-47.5-9.9-39.7-17.2-65.7-57.2-67.7-59.8-2-2.6-16.2-21.5-16.2-41s10.2-29.1 13.9-33.1c3.6-4 7.9-5 10.6-5 2.6 0 5.3 0 7.6.1 2.4.1 5.7-.9 8.9 6.8 3.3 7.9 11.2 27.4 12.2 29.4s1.7 4.3.3 6.9c-7.6 15.2-15.7 14.6-11.6 21.6 15.3 26.3 30.6 35.4 53.9 47.1 4 2 6.3 1.7 8.6-1 2.3-2.6 9.9-11.6 12.5-15.5 2.6-4 5.3-3.3 8.9-2 3.6 1.3 23.1 10.9 27.1 12.9s6.6 3 7.6 4.6c.9 1.9.9 9.9-2.4 19.1zM400 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zM223.9 413.2c-26.6 0-52.7-6.7-75.8-19.3L64 416l22.5-82.2c-13.9-24-21.2-51.3-21.2-79.3C65.4 167.1 136.5 96 223.9 96c42.4 0 82.2 16.5 112.2 46.5 29.9 30 47.9 69.8 47.9 112.2 0 87.4-72.7 158.5-160.1 158.5z"></path></svg>						</span>
										<span class="elementor-icon-list-text">Admin 2: 0851 1122 2164</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-far-envelope" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M464 64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V112c0-26.51-21.49-48-48-48zm0 48v40.805c-22.422 18.259-58.168 46.651-134.587 106.49-16.841 13.247-50.201 45.072-73.413 44.701-23.208.375-56.579-31.459-73.413-44.701C106.18 199.465 70.425 171.067 48 152.805V112h416zM48 400V214.398c22.914 18.251 55.409 43.862 104.938 82.646 21.857 17.205 60.134 55.186 103.062 54.955 42.717.231 80.509-37.199 103.053-54.947 49.528-38.783 82.032-64.401 104.947-82.653V400H48z"></path></svg>						</span>
										<span class="elementor-icon-list-text">walimatul@gmail.com</span>
									</li>
								<li class="elementor-icon-list-item">
											<span class="elementor-icon-list-icon">
							<svg aria-hidden="true" class="e-font-icon-svg e-fas-map-marker-alt" viewBox="0 0 384 512" xmlns="http://www.w3.org/2000/svg"><path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"></path></svg>						</span>
										<span class="elementor-icon-list-text">Tanggeung, Cianjur, Jawa Barat</span>
									</li>
						</ul>
						</div>
				</div>
		<div class="elementor-element elementor-element-7353f12 e-con-full e-flex wdp-sticky-section-no e-con e-child" data-id="7353f12" data-element_type="container" data-e-type="container">
				<div class="elementor-element elementor-element-e12bd37 elementor-widget elementor-widget-heading" data-id="e12bd37" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Pilihan Tema</h3>				</div>
				<div class="elementor-element elementor-element-7a4804f elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="7a4804f" data-element_type="widget" data-e-type="widget" data-widget_type="icon-list.default">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Tema Basic</span>
									</li>
								<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Tema Standar</span>
									</li>
								<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Tema Premium</span>
									</li>
								<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Tema Non-Wedding</span>
									</li>
						</ul>
						</div>
				</div>
		<div class="elementor-element elementor-element-2436d1c e-con-full e-flex wdp-sticky-section-no e-con e-child" data-id="2436d1c" data-element_type="container" data-e-type="container">
				<div class="elementor-element elementor-element-1e2b510 elementor-widget elementor-widget-heading" data-id="1e2b510" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Menu Lainnya</h3>				</div>
				<div class="elementor-element elementor-element-251e1e3 elementor-icon-list--layout-traditional elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list" data-id="251e1e3" data-element_type="widget" data-e-type="widget" data-widget_type="icon-list.default">
							<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Tentang Kami</span>
									</li>
								<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Blog</span>
									</li>
								<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Pendaftaran Reseller</span>
									</li>
								<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Kebijakan Privasi</span>
									</li>
								<li class="elementor-icon-list-item">
										<span class="elementor-icon-list-text">Syarat dan Ketentuan</span>
									</li>
						</ul>
						</div>
				</div>
					</div>
				</div>
		<div class="elementor-element elementor-element-f93b027 e-flex e-con-boxed wdp-sticky-section-no e-con e-parent" data-id="f93b027" data-element_type="container" data-e-type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
		<div class="elementor-element elementor-element-de664ea e-flex e-con-boxed wdp-sticky-section-no e-con e-child" data-id="de664ea" data-element_type="container" data-e-type="container" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
					<div class="e-con-inner">
				<div class="elementor-element elementor-element-3a911db wdp-sticky-section-no elementor-widget elementor-widget-heading" data-id="3a911db" data-element_type="widget" data-e-type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Copyright © 2026 Walimatul ID All Rights Reserved.</p>				</div>
				<div class="elementor-element elementor-element-14dca9e elementor-view-stacked elementor-absolute elementor-shape-circle elementor-widget elementor-widget-icon" data-id="14dca9e" data-element_type="widget" data-e-type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;,&quot;sticky&quot;:&quot;bottom&quot;,&quot;sticky_offset&quot;:10,&quot;sticky_on&quot;:[&quot;desktop&quot;,&quot;tablet&quot;,&quot;mobile&quot;],&quot;sticky_effects_offset&quot;:0,&quot;sticky_anchor_link_offset&quot;:0}" data-widget_type="icon.default">
							<div class="elementor-icon-wrapper">
			<a class="elementor-icon" href="https://api.whatsapp.com/send?phone=6285128002066&#038;text=Halo%20Walimatul%20iD" target="_blank">
			<svg aria-hidden="true" class="e-font-icon-svg e-fas-comment-alt" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M448 0H64C28.7 0 0 28.7 0 64v288c0 35.3 28.7 64 64 64h96v84c0 9.8 11.2 15.5 19.1 9.7L304 416h144c35.3 0 64-28.7 64-64V64c0-35.3-28.7-64-64-64z"></path></svg>			</a>
		</div>
						</div>
					</div>
				</div>
					</div>
				</div>
				</footer>
		
<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/hello-elementor/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<script src="https://walimatul.id/wp-content/plugins/weddingpress/assets/js/wdp-swiper.min.js" id="wdp-swiper-js-js"></script>
<script src="https://walimatul.id/wp-content/plugins/weddingpress/assets/js/qr-code.js" id="weddingpress-qr-js"></script>
<script src="https://walimatul.id/wp-content/plugins/weddingpress/assets/js/wdp-horizontal.js" id="wdp-horizontal-js-js"></script>
<script src="https://walimatul.id/wp-content/plugins/weddingpress/assets/js/exad-scripts.min.js?ver=2.10" id="exad-main-script-js"></script>
<script src="https://walimatul.id/wp-content/plugins/weddingsaas-pro/assets/plugins/custom/commentpress/saic_lib.js?ver=2.9.1" id="saic_library-js"></script>
<script id="wds_rsvp-js-extra">
var WDS_RSVP = {"ajaxurl":"https://walimatul.id/wp-admin/admin-ajax.php","nonce":"0bc7b5ad91","jPagesNum":"5","textCounterNum":"300","thanksComment":"Terima kasih atas ucapan Anda!","duplicateComment":"Anda mungkin membiarkan salah satu kolom kosong, atau menggandakan komentar.","guestMax":"2","textNavNext":"Next","textNavPrev":"Previous"};
//# sourceURL=wds_rsvp-js-extra
</script>
<script src="https://walimatul.id/wp-content/plugins/weddingsaas-pro/assets/js/wds-rsvp.js?ver=2.9.1" id="wds_rsvp-js"></script>
<script src="https://walimatul.id/wp-content/themes/hello-elementor/assets/js/hello-frontend.js?ver=3.4.7" id="hello-theme-frontend-js"></script>
<script src="https://walimatul.id/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=4.0.8" id="elementor-webpack-runtime-js"></script>
<script src="https://walimatul.id/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=4.0.8" id="elementor-frontend-modules-js"></script>
<script src="https://walimatul.id/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Bagikan di Facebook","shareOnTwitter":"Bagikan di Twitter","pinIt":"Buat Pin","download":"Unduh","downloadImage":"Unduh gambar","fullscreen":"Layar Penuh","zoom":"Perbesar","share":"Bagikan","playVideo":"Putar Video","previous":"Sebelumnya","next":"Selanjutnya","close":"Tutup","a11yCarouselPrevSlideMessage":"Slide sebelumnya","a11yCarouselNextSlideMessage":"Slide selanjutnya","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Layar lebar","value":2400,"default_value":2400,"direction":"min","is_enabled":false}},
"hasCustomBreakpoints":false},"version":"4.0.8","is_static":false,"experimentalFeatures":{"e_font_icon_svg":true,"additional_custom_breakpoints":true,"container":true,"e_optimized_markup":true,"theme_builder_v2":true,"hello-theme-header-footer":true,"nested-elements":true,"global_classes_should_enforce_capabilities":true,"e_variables":true,"e_opt_in_v4_page":true,"e_components":true,"e_interactions":true,"e_widget_creation":true,"import-export-customization":true,"e_pro_atomic_form":true,"mega-menu":true,"e_pro_variables":true,"e_pro_interactions":true},"urls":{"assets":"https:\/\/walimatul.id\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/walimatul.id\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/walimatul.id\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"cd3311cd88","atomicFormsSendForm":"fef5cff181"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description","hello_header_logo_type":"logo","hello_header_menu_layout":"horizontal","hello_footer_logo_type":"logo"},"post":{"id":0,"title":"Page not found - Walimatul iD","excerpt":""}};
//# sourceURL=elementor-frontend-js-before
</script>
<script src="https://walimatul.id/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=4.0.8" id="elementor-frontend-js"></script>
<script src="https://walimatul.id/wp-content/plugins/elementor-pro/assets/lib/smartmenus/jquery.smartmenus.min.js?ver=1.2.1" id="smartmenus-js"></script>
<script src="https://walimatul.id/wp-content/plugins/elementor-pro/assets/lib/sticky/jquery.sticky.min.js?ver=4.0.4" id="e-sticky-js"></script>
<script src="https://walimatul.id/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=4.0.4" id="elementor-pro-webpack-runtime-js"></script>
<script src="https://walimatul.id/wp-includes/js/dist/hooks.min.js?ver=dd5603f07f9220ed27f1" id="wp-hooks-js"></script>
<script src="https://walimatul.id/wp-includes/js/dist/i18n.min.js?ver=c26c3dc7bed366793375" id="wp-i18n-js"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="elementor-pro-frontend-js-before">
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/walimatul.id\/wp-admin\/admin-ajax.php","nonce":"d3ecbfb0a7","urls":{"assets":"https:\/\/walimatul.id\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/walimatul.id\/wp-json\/"},"settings":{"lazy_load_background_images":true},"popup":{"hasPopUps":true},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"},"x-twitter":{"title":"X"},"threads":{"title":"Threads"}},
"facebook_sdk":{"lang":"id_ID","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/walimatul.id\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
//# sourceURL=elementor-pro-frontend-js-before
</script>
<script src="https://walimatul.id/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=4.0.4" id="elementor-pro-frontend-js"></script>
<script src="https://walimatul.id/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=4.0.4" id="pro-elements-handlers-js"></script>
<script id="weddingpress-wdp-js-extra">
var cevar = {"ajax_url":"https://walimatul.id/wp-admin/admin-ajax.php","plugin_url":"https://walimatul.id/wp-content/plugins/weddingpress/","guestbook_nonce":"112ea91922"};
//# sourceURL=weddingpress-wdp-js-extra
</script>
<script src="https://walimatul.id/wp-content/plugins/weddingpress/assets/js/wdp.min.js?ver=2.10" id="weddingpress-wdp-js"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://walimatul.id/wp-includes/js/wp-emoji-release.min.js?ver=6.9.4"}}
</script>
<script type="module">
/*! This file is auto-generated */
const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window._wpemojiSettings=a,"wpEmojiSettingsSupports"),s=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!a(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s[e]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),c.toString(),p.toString()].join(",")+"));",a=new Blob([e],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports[n]=e[n],a.supports.everything=a.supports.everything&&a.supports[n],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports[n]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))});
//# sourceURL=https://walimatul.id/wp-includes/js/wp-emoji-loader.min.js
</script>

</body>
</html>
